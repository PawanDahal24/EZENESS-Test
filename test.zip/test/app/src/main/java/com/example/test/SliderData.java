package com.example.test;

public class SliderData {

    private String imgUrl;

    public SliderData(String imgUrl){
        this.imgUrl = imgUrl;
    }
    public String getImgUrl(){
        return imgUrl;
    }
    public void setImgUrl(String imgUrl){
        this.imgUrl = imgUrl;
    }
}
